<?php
require_once __DIR__ . '/../../core/Database.php';
require_once __DIR__ . '/../models/Produto.php';
class ProdutoController
{
private $produtoModel;
public function __construct()
{
$database = new Database();
$db = $database->connect();
$this->produtoModel = new Produto($db);
}
public function index()
{
    $produtos = $this->produtoModel->all();
    require __DIR__ . '/../views/produtos/index.php';
}
public function create()
{
    require __DIR__ . '/../views/produtos/create.php';
}

public function store()
{
    $this->produtoModel->create($_POST);
    header("Location: ?action=index");
}
public function edit()
{
    $id = $_GET['id'];
    $produto = $this->produtoModel->find($id);
    require __DIR__ . '/../views/produtos/edit.php';
}
public function update()
{
    $id = $_GET['id'];
    $this->produtoModel->update($id, $_POST);
    header("Location: ?action=index");
}
public function delete()
{
    $id = $_GET['id'];
    $this->produtoModel->delete($id);
    header("Location: ?action=index");
}
}