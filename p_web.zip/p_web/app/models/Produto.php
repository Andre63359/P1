<?php
class Produto
{
private $conn;
private $table = 'produtos';
public function __construct($db)
{
$this->conn = $db;
}
public function all()
{
    $sql = "SELECT * FROM " . $this->table;
    $stmt = $this->conn->prepare($sql);
    $stmt->execute();

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
public function find($id)
{
    $sql = "SELECT * FROM {$this->table} WHERE id = :id";
    $stmt = $this->conn->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

public function create($dados)
{
    $sql = "INSERT INTO {$this->table} (nome, preco, quantidade)
    VALUES (:nome, :preco, :quantidade)";
    $stmt = $this->conn->prepare($sql);
    return $stmt->execute([
    ':nome' => $dados['nome'],
    ':preco' => $dados['preco'],
    ':quantidade' => $dados['quantidade']
    ]);
}
public function update($id, $dados)
{
    $sql = "UPDATE {$this->table}
    SET nome = :nome, preco = :preco, quantidade = :quantidade
    WHERE id = :id";
    $stmt = $this->conn->prepare($sql);
    return $stmt->execute([
    ':nome' => $dados['nome'],
    ':preco' => $dados['preco'],
    ':quantidade' => $dados['quantidade'],
    ':id' => $id
    ]);
}
public function delete($id)
{
    $sql = "DELETE FROM {$this->table} WHERE id = :id";
    $stmt = $this->conn->prepare($sql);
    return $stmt->execute([':id' => $id]);
    
}
}